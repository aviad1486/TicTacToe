#ifndef GAME_H
#define GAME_H

void announceWinner(int winner);
int game();

#endif //GAME_H
