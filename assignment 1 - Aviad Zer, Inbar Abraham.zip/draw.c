#include "draw.h"
#include "graph.h"
#include <string.h>

// print the given text at the given position with the given color
int printCentered(int y, int color, const char *text) {
    // BEGIN IMPLEMENTATION
    print(3, y, 6, text);
    return 0;
    // END IMPLEMENTATION
}

// Mark a square at the given position with the given color
void drawMark(int x, int y, int color) {

    // BEGIN IMPLEMENTATION

    // Draw a square at the given position
    drawSquare(x, y, 4);

    // END IMPLEMENTATION
}

// Draw the top row of the game board
static void drawTopRow(int left, int top, int width, int color) {

    // BEGIN IMPLEMENTATION
    // Draw the top-left box
    drawTopLeftBox(left, top, color);

    // Draw the top-middle boxes
    for (int i = 1; i < width - 1; i++)  {
        drawTopMiddleBox(left + i * CELL_WIDTH, top, color);
    }

    // Draw the top-right box
    drawTopRightBox(left + (width - 1) * CELL_WIDTH, top, color);
    // END IMPLEMENTATION
}

// Draw the middle rows of the game board
static void drawMiddleRows(int left, int top, int width, int height, int color) {

    // BEGIN IMPLEMENTATION
      for (int i = 1; i < height - 1; i++)  {
        // Draw the middle-left box
        drawMiddleLeftBox(left, top + i * CELL_HEIGHT, color);

        // Draw the middle-middle boxes
        for (int j = 1; j < width - 1; j++) {
            drawMiddleMiddleBox(left + j * CELL_WIDTH, top + i * CELL_HEIGHT, color);
        }

        // Draw the middle-right box
        drawMiddleRightBox(left + (width - 1) * CELL_WIDTH, top + i * CELL_HEIGHT, color);
    }
    // END IMPLEMENTATION
}

// Draw the bottom row of the game board
static void drawBottomRow(int left, int top, int width, int height, int color) {

    // BEGIN IMPLEMENTATION
    // Draw the bottom-left box
    drawBottomLeftBox(left, top + (height - 1) * CELL_HEIGHT, color);

    // Draw the bottom-middle boxes
    for (int i = 1; i < width - 1; i++) {
        drawBottomMiddleBox(left + i * CELL_WIDTH, top + (height - 1) * CELL_HEIGHT, color);
    }

    // Draw the bottom-right box
    drawBottomRightBox(left + (width - 1) * CELL_WIDTH, top + (height - 1) * CELL_HEIGHT, color);
    // END IMPLEMENTATION
}

// Draw the game board
void drawBoard(int left, int top, int width, int height, int color) {

    // BEGIN IMPLEMENTATION
     // Draw the top row
    drawTopRow(left, top, width, color);

    // Draw the middle rows
    drawMiddleRows(left, top, width, height, color);

    // Draw the bottom row
    drawBottomRow(left, top, width, height, color);
    // END IMPLEMENTATION
}