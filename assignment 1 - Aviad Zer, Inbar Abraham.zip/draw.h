#ifndef DRAW_H
#define DRAW_H

extern int n, len;

#define BOARD_LEFT 2   // x position of the board
#define BOARD_TOP 2    // y position of the board
#define CELL_WIDTH 9   // cell_t width
#define CELL_HEIGHT 5  // cell_t height

int printCentered(int y, int color, const char *text);
void drawBoard(int left, int top, int width, int height, int color);
void drawMark(int x, int y, int color);

#endif // DRAW_H
