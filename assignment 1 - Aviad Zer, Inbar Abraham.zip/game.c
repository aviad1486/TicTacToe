#include "game.h"
#include "draw.h"
#include "graph.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

typedef struct cell {
    // BEGIN IMPLEMENTATION
    int id;
    int token;
    int xPos;
    int yPos;
    struct cell *next[4];
} cell_t;
// END IMPLEMENTATION

// set the mark of pc to the given player
void setMark(cell_t *pc, int player) {
    // BEGIN IMPLEMENTATION
    if (player == 1){
        drawSquare(pc->xPos, pc->yPos, 4);
    }
    else{
        drawSquare(pc->xPos, pc->yPos, 3);
    }
    // END IMPLEMENTATION
}

// clear the mark of pc
void clearMark(cell_t *pc) {
    // BEGIN IMPLEMENTATION
    drawSquare(pc->xPos, pc->yPos, 0);
    // END IMPLEMENTATION
}

// set the token of the given cell to the given player
void setToken(cell_t *pc, int player) {
    // BEGIN IMPLEMENTATION
    if (pc->token != 0){
        return;
    }
    pc->token = player;
    // END IMPLEMENTATION
}

// get the cell index from the given x and y position
int getCellIdx(int x, int y) {
    // BEGIN IMPLEMENTATION
    return y * n + x;
    // END IMPLEMENTATION
}

// initialize the cells of the board
cell_t *initCells(int left, int top, int width, int height) {

    // initialize the cell
    cell_t *cells = (cell_t *)malloc(sizeof(cell_t) * n * n);

    for (int y = 0; y < n; y++){
        for (int x = 0; x < n; x++){
            // BEGIN IMPLEMENTATION
            int idx = getCellIdx(x, y);
            cells[idx].id = idx;
            cells[idx].token = 0;
            cells[idx].xPos = left + x * width;
            cells[idx].yPos = top + y * height;

            // Initialize the next array to NULL initially
            for (int i = 0; i < 4; i++){
                cells[idx].next[i] = NULL;
            }

            // Set the next pointers only if they are within bounds
            if (x > 0) {
                cells[idx].next[LEFT] = &cells[getCellIdx(x - 1, y)];
            }
            if (x < n - 1) {
                cells[idx].next[RIGHT] = &cells[getCellIdx(x + 1, y)];
            }
            if (y > 0) {
                cells[idx].next[UP] = &cells[getCellIdx(x, y - 1)];
            }
            if (y < n - 1) {
                cells[idx].next[DOWN] = &cells[getCellIdx(x, y + 1)];
            }
        }
    }
    // END IMPLEMENTATION

    return cells;
}

// Count the sequence of tokens in the given direction
int countSeq(cell_t *pc, int dir) {
    int count = 1; // Start with 1 to include the current cell
    // BEGIN IMPLEMENTATION
    int oppDir;
    if (dir == 0) {
        oppDir = 2;
    }
    else if (dir == 2) {
        oppDir = 0;
    }
    else if (dir == 1) {
        oppDir = 3;
    }
    else {
        oppDir = 1;
    }
    // Check in the first direction
    cell_t *current = pc->next[dir];
    while (current != NULL && current->token == pc->token) {
        count++;
        current = current->next[dir];
    }

    // Check in the opposite direction
    current = pc;
    while (current != NULL && current->token == pc->token) {
        count++;
        current = current->next[oppDir];
    }
    // END IMPLEMENTATION
    return count - 1; // Subtract 1 as the starting cell is counted twice
}

// Count the sequence of tokens in the diagonal direction d1 and d2
int countDiagSeq(cell_t *pc, int d1, int d2) {
    int count = 1; // Start with 1 to include the current cell
    // BEGIN IMPLEMENTATION
    int oppDir1;
    int oppDir2;
    if (d1 == 0 && d2 == 1) {
        oppDir1 = 2;
        oppDir2 = 3;
    }
    else if (d1 == 2 && d2 == 3) {
        oppDir1 = 0;
        oppDir2 = 1;
    }
    else if (d1 == 2 && d2 == 1) {
        oppDir1 = 0;
        oppDir2 = 3;
    }
    else { // (d1 == 0 && d2 == 3)
        oppDir1 = 2;
        oppDir2 = 1;
    }
    // Count in the first diagonal direction
    cell_t *current = pc->next[d1];
    if (current != NULL) {
        current = current->next[d2];
    }
    while (current != NULL && current->token == pc->token) {
        count++;
        if (current->next[d1] != NULL) {
            current = current->next[d1]->next[d2];
        }
        else {
            break;
        }
    }

    // Reset to the starting cell
    current = pc->next[oppDir1];
    if (current != NULL) {
        current = current->next[oppDir2];
    }

    // Count in the opposite diagonal direction
    while (current != NULL && current->token == pc->token) {
        count++;
        if (current->next[oppDir1] != NULL){
            current = current->next[oppDir1]->next[oppDir2];
        }
        else{
            break;
        }
    }
    // END IMPLEMENTATION
    return count;
}

// Check if the given cell is part of a winning set
int isWin(cell_t *pc){
    int win = 0;
    // BEGIN IMPLEMENTATION
    // Check for a winning sequence in all directions (up, right, down, left, diagonals)
    for (int dir = 0; dir < 4; dir++) {
        int count = countSeq(pc, dir);
        if (count == n){
            win = 1; // Winning sequence found
            return win;
        }
    }
    // Check diagonals works from top right to left bottom and from right bottom to top left
    int diagCount1 = countDiagSeq(pc, UP, RIGHT);   // from left bottom to top right
    int diagCount2 = countDiagSeq(pc, DOWN, RIGHT); // from top left to right bottom
    int diagCount3 = countDiagSeq(pc, DOWN, LEFT);  // from right top to left bottom
    int diagCount4 = countDiagSeq(pc, UP, LEFT);    // from right bottom to left top

    if (diagCount1 == n || diagCount2 == n || diagCount3 == n || diagCount4 == n) {
        win = 1; // Winning diagonal sequence found
        return win;
    }
    // END IMPLEMENTATION
    return win;
}

// BONUS 2: look for an empty cell to the left or the right
cell_t *lookLeftOrRight(cell_t *pc, int dir) {
    // BEGIN IMPLEMENTATION
    
    // END IMPLEMENTATION
    return pc;
}

// BONUS 2: look for an empty cell to the left and right of the given cell simultaneously
cell_t *lookLeftAndRight(cell_t *pc) {
    // BEGIN IMPLEMENTATION
    
    // END IMPLEMENTATION
    return pc;
}

// BONUS 2: look for an empty cell above or below the given cell. on each row, look for an
// Empty cell to the left and right simultaneously before proceeding to the next row
cell_t *lookUpOrDown(cell_t *pc, int dir) {
    // BEGIN IMPLEMENTATION
    
    // END IMPLEMENTATION
    return pc;
}

// BONUS 3: look for an empty cell around the given cell using breadth-first search.
// After checking the current cell, search in clockwise order starting from the cell above it.
cell_t *lookAround(cell_t *pc) {
    // BEGIN IMPLEMENTATION

    // Create a queue of cells and enqueue the given cell

    // Search for an empty cell using breadth-first search

    // END IMPLEMENTATION
    return NULL;
}

// move the mark left or right (stop at the edge of the board)
// BONUS 1: skip to the opposite edge
cell_t *moveLeftOrRight(cell_t *pc, int player, int dir) {
    // BEGIN IMPLEMENTATION
    if (dir == LEFT) {
        if (pc->next[LEFT] != NULL)  {
            pc = pc->next[LEFT]; // Move left if not at the left edge
        }
        else  {
            // Skip to the rightmost cell of the same row
            while (pc->next[RIGHT] != NULL)
            {
                pc = pc->next[RIGHT];
            }
        }
    }
    else if (dir == RIGHT) {
        if (pc->next[RIGHT] != NULL) {
            pc = pc->next[RIGHT]; // Move right if not at the right edge
        }
        else {
            // Skip to the leftmost cell of the same row
            while (pc->next[LEFT] != NULL)
            {
                pc = pc->next[LEFT];
            }
        }
    }

    // END IMPLEMENTATION
    return pc;
}

// move the mark up or down (stop at the edge of the board)
// BONUS 1: skip to the opposite edge
cell_t *moveUpOrDown(cell_t *pc, int player, int dir){
    // BEGIN IMPLEMENTATION
    if (dir == UP)  {
        if (pc->next[UP] != NULL)  {
            pc = pc->next[UP]; // Move up if not at the top edge
        }
        else  {
            // Skip to the bottommost cell of the same column
            while (pc->next[DOWN] != NULL)
            {
                pc = pc->next[DOWN];
            }
        }
    }
    else if (dir == DOWN) {
        if (pc->next[DOWN] != NULL)  {
            pc = pc->next[DOWN]; // Move down if not at the bottom edge
        }
        else  {
            // Skip to the topmost cell of the same column
            while (pc->next[UP] != NULL) {
                pc = pc->next[UP];
            }
        }
    }

    // END IMPLEMENTATION
    return pc;
}

// Process a game turn
cell_t *playTurn(cell_t *pc, int player) {
    // BEGIN IMPLEMENTATION
    // Check if any cells are empty
    int emptyCellsExist = 0;
    for (int i = 0; i < n * n; i++) {
        if (pc[i].token == 0) {
            emptyCellsExist = 1;
            break;
        }
    }
    // Draw case
    if (!emptyCellsExist) {
        announceWinner(0);
        return NULL;
    }

    // Handle left, right, up, down commands (loop until the player sets a token or quits)
    int command;
    do
    {
        // Get the player's command
        command = getCommand();
        // Move the player's mark based on the command
        cell_t *prevPC = pc;

        switch (command)
        {

        case LEFT:
            pc = moveLeftOrRight(pc, player, command);
            if (prevPC->token == 0)
            {
                clearMark(prevPC);
            }
            if (pc->token == 0)
            {
                setMark(pc, player);
            }

            break;
        case RIGHT:
            pc = moveLeftOrRight(pc, player, command);
            if (prevPC->token == 0)
            {
                clearMark(prevPC);
            }
            if (pc->token == 0)
            {
                setMark(pc, player);
            }
            break;
        case UP:
            pc = moveUpOrDown(pc, player, command);
            if (prevPC->token == 0)
            {
                clearMark(prevPC);
            }
            if (pc->token == 0)
            {
                setMark(pc, player);
            }
            break;
        case DOWN:
            pc = moveUpOrDown(pc, player, command);
            if (prevPC->token == 0)
            {
                clearMark(prevPC);
            }
            if (pc->token == 0)  
            {
                setMark(pc, player);
            }
            break;
        case TOKEN:
            if (pc->token == 0) {
                if (player == 1) {
                    setToken(pc, 1);
                    drawEx(pc->xPos, pc->yPos, 5);
                }
                else  {
                    setToken(pc, 2);
                    drawOh(pc->xPos, pc->yPos, 6);
                }
            }
            return pc;
            break;
        }

    } while (command != QUIT);
    // Return the cell the player placed the token in or NULL if he quits
    return pc;
    // END IMPLEMENTATION
}

// Game engine main loop
int game() {
    cell_t *root = NULL;

    // BEGIN IMPLEMENTATION
    // Print the title, prepare game board, initialize cells
    
    char title[] = "Welcome To Tic-Tic-Toe";
    setBg(0);
    startGraphics(0);
    printCentered(0, 7, title);
    root = initCells(2, 2, 9, 5);
    int currentPlayer = 1;
    cell_t *placedCell;
    drawBoard(1, 1, n, n, 5);
    do
    {
        // Play the turn for the current player
        placedCell = playTurn(root, currentPlayer);
        // Check if the player placed a token
        if (placedCell != NULL)  {
            // Check if the current player wins
            if (isWin(placedCell))  {
                announceWinner(currentPlayer);
                break;
            }
        }

        // Switch to the next player
        if (currentPlayer == 1)  {
            currentPlayer = 2;
        }
        else {
            currentPlayer = 1;
        }

    } while (placedCell != NULL); // Continue until a player quits or the game is draw

    // Stop the graphics engine and free the memory
    stopGraphics();

    // END IMPLEMENTATION
    free(root);
    return 0; // Draw
}

// Announce the winner (or draw)
void announceWinner(int winner) {
    // BEGIN IMPLEMENTATION
    if (winner > 0){
        printf("Player %d wins! Congratulations!\n", winner);
    }
    else  {
        printf("It's a draw! Better luck next time.\n");
    }
    // END IMPLEMENTATION
}