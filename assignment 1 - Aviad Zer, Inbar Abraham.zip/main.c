#include <stdio.h>
#include <stdlib.h>
#include "graph.h"
#include "game.h"

int n, len; // effectively constant

// print usage information
static int usage(const char *filename) {
    // BEGIN IMPLEMENTATION
    printf("n: boards size will be n xPos n (min: 3)\nlen: winning set length (min: 3, max: n, default: n)");
    // print usage information (see sample solution output)

    // END IMPLEMENTATION
    return EXIT_FAILURE;
}

int main(int argc, char *argv[]) {

    // BEGIN IMPLEMENTATION

    // check that the command line arguments are valid. if not, print usage and exit,
     if (argc < 2 || argc > 3) {
        usage(argv[0]);
        return EXIT_FAILURE;
    }
    // otherwise, initialize n and len global variables
    n = atoi(argv[1]); // atoi casts the argv[1] to integer
    // start the graphic engine
     if (n < 3){
        printf("Error: Invalid board size. Please provide a size of at least 3.\n");
        usage(argv[0]);
        return EXIT_FAILURE;
    }
    // Parse optional command-line argument as the winning set length (default: n)
    if (argc == 3) {
    len = atoi(argv[2]);
    } 
    else {
    len = n;
    }   

    // Validate that len is within a reasonable range (e.g., between 3 and n)
    if (len < 3 || len > n) {
        printf("Error: Invalid winning set length. Please provide a length between 3 and %d.\n", n);
        usage(argv[0]);
        return EXIT_FAILURE;
    }

    
    // run the game
    game(); // graphic engine starts and stops in game()
    // END IMPLEMENTATION

    printf("\n\n");

    return EXIT_SUCCESS;
}