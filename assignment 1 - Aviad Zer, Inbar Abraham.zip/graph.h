#ifndef GRAPH_H
#define GRAPH_H

// colors
#define COLOR_BLACK	  0
#define COLOR_RED     1
#define COLOR_GREEN	  2
#define COLOR_YELLOW  3
#define COLOR_BLUE    4
#define COLOR_MAGENTA 5
#define COLOR_CYAN    6
#define COLOR_WHITE   7

// commands
#define UP    0  // go up (up arrow)
#define RIGHT 1  // go right (right arrow)
#define DOWN  2  // go down (down arrow)
#define LEFT  3  // go left (left arrow)
#define TOKEN 4  // set token (space key)
#define QUIT  5  // quit game (esc key)

/**
 * Start the graphics engine (must be called before any other graphic function).
 */
void startGraphics(int bgColor);

/**
 * Stops the graphics engine (must be called before exiting the game to reset the state of the terminal).
 */
void stopGraphics();

/**
 * Reads a command from the user (see command definitions above).
 */
int getCommand();

/**
 * Sets the background color.
 */
void setBg(int color);

/**
 * Toggle underline mode on and off.
 */
void toggleUnderline();

/**
 * Toggle dim mode on and off.
 */
void toggleDim();

/**
 * Toggle bold mode on and off.
 */
void toggleBold();

/**
 * Print a string at (x, y) with the given color.
 */
void print(int x, int y, int color, const char *text);

/**
 * Draws a text-graphics X at (x, y) with the given color.
 */
void drawEx(int x, int y, int color);

/**
 * Draws a text-graphics O at (x, y) with the given color.
 */
void drawOh(int x, int y, int color);

/**
 * Draws a an empty square at (x, y) with the given color.
 */
void drawSquare(int x, int y, int color);

/**
 * Draws a grid box at (x, y) with the given color.
 */
void drawTopLeftBox(int x, int y, int color);
void drawTopMiddleBox(int x, int y, int color);
void drawTopRightBox(int x, int y, int color);
void drawMiddleLeftBox(int x, int y, int color);
void drawMiddleMiddleBox(int x, int y, int color);
void drawMiddleRightBox(int x, int y, int color);
void drawBottomLeftBox(int x, int y, int color);
void drawBottomMiddleBox(int x, int y, int color);
void drawBottomRightBox(int x, int y, int color);

#endif // GRAPH_H